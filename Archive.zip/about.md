---
layout: default
title: About
---

### Christoforos Kapsalis  

Data‑driven marketer specialising in BI & Power BI.  
Incoming Fulbright MSc Marketing scholar at Syracuse University.

* LinkedIn → <https://www.linkedin.com/in/christoforos-kapsalis/>  